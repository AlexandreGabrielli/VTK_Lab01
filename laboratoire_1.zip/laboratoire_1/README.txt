# prérequis
python 2.7
vtk

# lancé la commande 
python olaf.py dans un prompt adéquat 